# Results

## Complete the prefix

### Prefix 1

```
<connor> my God it looks like the shittiest Cafe </connor>
<connor> in all of Japan it's like it's like yeah </connor>
<joey> it has an outside Terrace and it's </joey>
<connor> let me show you a picture okay it's like </connor>
<joey> unfair to even call this a Terrace do </joey>
<joey> they not just think to like walk into </joey>
<connor> like a Starbucks I think I think they </connor>
<joey> didn't want to go to Starbucks and also </joey>
<joey> I think they were also like look at this </joey>
```

True Completion:

```
<joey> oh </joey>
<joey> that doesn't even look like a cafe and </joey>
<joey> this is something that I've learned and </joey>
<joey> I know this because I had the same thing </joey>
<joey> myself I said like it is super </joey>
<joey> intimidating in Japan for people who've </joey>
<joey> never gone to Japan or Asia in general </joey>
<joey> to to to imagine having to go into a </joey>
<joey> building without being able to see it </joey>
<joey> immediately what's inside yes yeah so I </joey>
<joey> think for them my parents it was like </joey>
<joey> okay well Terrace equals I can kind of </joey>
<joey> see what's going on and then there's </joey>
<joey> also hundreds of miscommunications they </joey>
<joey> keep telling me about where they're like </joey>
<joey> my mom is obsessed with cider as right a </joey>
<joey> British woman yeah wants to drink siding </joey>
<joey> alcohol excited yeah which just doesn't </joey>
<joey> exist in Japan no no and in America it's </joey>
<connor> called hard cider but here it's like </connor>
<connor> what do they call it Cedar but then </connor>
<joey> there's also normal cider which is </joey>
<connor> yeah you can imagine </connor>
```

GPT2-Small:

```
<joey> Starbucks in Japan there's like the </joey>
<garnt> kind of like two rows of like a giant </garnt>
<joey> Starbucks in this corner and I'm just like </joey>
<joey> I don't know what's going on you know </joey>
<joey> we're talking about the Starbucks </joey>
<joey> but yeah they have like a table that </joey>
<joey> has a table that has tables to hold the </joey>
<joey> food and sometimes they have like a </joey>
<joey> table that has a tray for drinks </joey>
<joey> yeah yeah yeah i've seen some kind of </joey>
```

GPT2-Med:

```
<joey> you're walking in the wrong direction yeah </joey>
<joey> this is what I thought I thought </joey>
<joey> like the decor is [ __ ] ugly yeah </joey>
<connor> yeah but like I don't know I I don't know </connor>
<connor> I've been it's just been the fact that </connor>
<joey> it's been like this for like a long time </joey>
<joey> it's been like an icon that's always </joey>
<joey> there but I don't know if it's been the </joey>
<joey> place that it's been like this as a </joey>
```

Bloom 560:

```
<connor> [ __ ] but I mean I think you can get a </connor>
<connor> Starbucks for the price you can get a </connor>
<connor> Starbucks for the price that is just a </connor>
<connor> lot of money it's a lot of money yeah yeah </connor>
<garnt> but I remember when we first went to </garnt>
<garnt> Japan and we were trying to find like </garnt>
<garnt> Tescos and stuff like that we were </garnt>
<garnt> like oh what is this we just found a </garnt>
<garnt> Tesco's here what is this it's a </garnt>
<garnt> Tesco's and it's like the one thing I </garnt>
<garnt> remember the the first time I went to </garnt>
<garnt> Japan and they were like oh you can get </garnt>
<garnt> some Tesco's here it's like a lot of </garnt>
<garnt> money for some [ __ ] and I'm like I was </garnt>
<garnt> like oh that's a [ __ ] Tesco's okay </garnt>
<connor> it's still like a [ __ ] Tesco's </connor>
<garnt> okay so we we go to there and it's </garnt>
<garnt> like 20 bucks yeah and it was like </garnt>
<garnt> the [ __ ] worst Tesco's I've had in </garnt>
<garnt> my life because it was like it was </garnt>
<garnt> literally like they were like they </garnt>
<garnt> were like they were like oh you can get </garnt>
<garnt> some Tesco's here with the price of </garnt>
<garnt> like a normal Tesco's like yeah a bit </garnt>
<garnt> extra yeah and we were like oh okay </garnt>
<garnt> they're like what can we get we don't </garnt>
<garnt> know what the [ __ ] they were like no </garnt>
<garnt> problem we'll try and we'll try and find </garnt>
<garnt> some Tesco's to get some Tesco's here </garnt>
<garnt> and we were like oh okay okay and </garnt>
<garnt> they      </garnt>
<garnt> [Applause] </garnt>
<connor> yeah it's the one time in the life </connor>
<connor> where someone's like well I don't think </connor>
<garnt> I want to be here anymore so I just want </garnt>
<connor> to be here and I just want to be there </connor>
<garnt> I don't know what the [ __ ] it's like </garnt>
<garnt> it's like it's like it's kind of like </garnt>
<garnt> the same kind of like yeah because </garnt>
<garnt> every you know     </garnt>
<garnt>        </garnt>
<connor>       </connor>
<garnt>       </garnt>
<garnt> I mean you know I don't know   </garnt>
<garnt>       </garnt>
<joey>       </joey>
<joey> the      </joey>
<joey>       </joey>
<connor>          </connor>
<joey>        </joey>
<garnt>           </garnt>
<garnt>           </garnt>
<garnt>           </garnt>
<connor>             </conno      </conno>
           </conno        </conno      </conno                                                                                                                                                                                                                                                                              to the point where no one else is saying </joey>
<joey> that this is the best
fucking thing in the world. </joey>
<joey> - I feel like the only
time that some people </joey>
<joey> actually watch it is
when it gets to a point </joey>
<joey> where you start to be in
the zone where you know, </joey>
<joey> you start to be a bit more
familiar with the show, </joey>
<garnt> you start to be like, "Oh, okay." </garnt>
<garnt> - Yeah. </garnt>
<joey> - But I feel like that's
such a small step, right? </joey>
<joey> Because at the end of the
day, the show doesn't have </joey>
<joey> the same audience as "Dragon Ball Z." </joey>
```

LLaMA 7B:

```
<garnt> beautiful Terrace </garnt>
<garnt> like this is so much better than
Starbucks Terrace is this so much </garnt>
<joey> better so I'm like if it's this bad </joey>
<garnt> then I don't wanna go I'm like let's just </garnt>
<garnt> go to Starbucks let's go to Starbucks </garnt>
<connor> because it's like it's just so nice and </connor>
<connor> it's so good it's like I want to go in </connor>
<connor> I'm like oh this is this is so pretty </connor>
<connor> this is pretty right and it's like </connor>
<connor> this is a perfect example of like </connor>
<connor> like it's like what kind of Japan </connor>
<connor> experience are you looking for right </connor>
<connor> because if you don't mind paying a lot </connor>
<connor> and like having a terrible waiter service </connor>
<connor> and having a bad food experience </connor>
<connor> and being like oh god what is this I've </connor>
<connor> never tasted anything like this before </connor>
<connor> but it's fucking delicious that is </connor>
<connor> the Japanese experience you know right </connor>
<joey> so when we went to Tokyo it was like </joey>
<joey> there was some some very good
experiences but most of </joey>
<joey> the time there was always like these </joey>
<joey> things where like it's like the bad </joey>
<joey> food or the bad service was like so </joey>
<joey> much worse than the good experience </joey>
<joey> that you were having that was like the </joey>
<joey> whole experience of going to Japan yeah </joey>
<connor> I remember when we went to the first </connor>
```

### Prefix 2

```
<connor> it's just like it's it's very fun taking </connor>
<connor> them around but after like like multiple </connor>
<connor> days of this I've been getting this same </connor>
<connor> question I'm like I'm gonna lose </connor>
<connor> my mind being asked these questions over </connor>
<connor> and over again but it's been fun they </connor>
<connor> love the bullet trains everyone seems to </connor>
<connor> love bullet trains as well every foreign </connor>
<joey> person I think people from outside Japan </joey>
<joey> just like find that concept so insane </joey>
<joey> yeah because it's like well like I think </joey>
```

True Completion:

```
<joey> like China is the only other country </joey>
<joey> that has trains that go that fast yeah I </joey>
<connor> think I think no Europe has high speed </connor>
<joey> rails does it yeah I don't think it's as </joey>
<garnt> well connected nearly as well connected </garnt>
<joey> yeah or run on time or because I think </joey>
<connor> like a million people a day use the </connor>
<garnt> shinkansen which is like insane amounts </garnt>
```

GPT2-Small:

```
<garnt> Japan is very, very small I think a lot of </garnt>
<garnt> the big cities in like Southeast Asia </garnt>
<garnt> are very small but you can still have </garnt>
<garnt> like a very traditionalist cuisine </garnt>
<garnt> you have a traditionalist culture as well </garnt>
<connor> and people are just like oh yeah </connor>
<connor> okay I'm gonna go into like a Southeast </connor>
<connor> Asian restaurant and I'm like oh my God </connor>
```

GPT2-Med:

```
<connor> it's just like it's it's very fun taking </connor>
<connor> them around but after like like multiple </connor>
<connor> days of this I've been getting this same </connor>
<connor> question I'm like I'm gonna lose </connor>
<connor> my mind being asked these questions over </connor>
<connor> and over again but it's been fun they </connor>
<connor> love the bullet trains everyone seems to </connor>
<connor> love bullet trains as well every foreign </connor>
<joey> person I think people from outside Japan </joey>
<joey> just like find that concept so insane </joey>
<joey> yeah because it's like well like I think </joey>
<joey> it's because it just like it's just </joey>
<joey> like every single thing there is like </joey>
<joey> built with a purpose so like you know </joey>
<joey> people would have like they would have </joey>
<joey> like a train station and then they </joey>
<connor> would have like an arcade yeah you know </connor>
<connor> like a bunch of like different arcades </connor>
```

Bloom 560:

```
<joey> like all the questions you have about </joey>
<joey> like the show are like very personal questions </joey>
<joey> but I think especially for me like </joey>
<joey> I feel like in terms of like my </joey>
<joey> Japanese uh my Japanese speaking skills </joey>
<connor> and everything like that and all the </connor>
<connor> kinds of social skills that I have and </connor>
<connor> everything like that I think like the </connor>
<connor> the first time I watched the show </connor>
<connor> immediately I was like oh I want to be </connor>
<connor> in that kind of situation and I was like </connor>
<connor> you know what I think about the </connor>
<connor> situation I'm like damn this is just </connor>
<connor> [ __ ] bad because it's like well I I </connor>
<connor> don't want to be in that situation </connor>
<connor> yeah but what I will say is like I </connor>
<joey> think it's really interesting how I </joey>
<joey> found myself on this journey and the </joey>
<joey> journey itself and the fact that it </joey>
<joey> really made me want to do it again and </joey>
<joey> to learn more Japanese and have fun with </joey>
<joey> more people and make my life a little bit </joey>
<joey> easier for a little bit but also it </joey>
<joey> definitely made me think about it more </joey>
<joey> deeply because I was like what if I </joey>
<joey> just like just like maybe not make my </joey>
<joey> life so [ __ ] difficult but for </joey>
<joey> myself I think it made me a lot more </joey>
<joey> like open to be like well no I I I know </joey>
<joey> this is a difficult thing like that I </joey>
<joey> can deal with it I can I can deal with it </joey>
<joey> but I have to be careful of like </joey>
<joey> um I don't know like I I feel like </joey>
<joey> especially like in the case with like </joey>
<joey> English especially right because it's </joey>
<joey> a language that I know nothing about </jey>
<joey> it's it's a language that you know </joey>
<joey> nothing about you know and it's a </joey>
<joey> language that you know you can't speak </joey>
<joey> and it's a language that you know you </joey>
<joey> can't like I don't know how ugh ugh </joey>
```

LLaMA 7B:

```
<joey> in Australia we have a train system that </joey>
<connor> is really fast it's like the bullet </connor>
<joey> trains are faster than our high speed </joey>
<joey> trains but it's not like a bullet train </joey>
<garnt> where it goes from point A to point B on </garnt>
<garnt> time that is kind of crazy to me yeah it's </garnt>
<garnt> just like the world is getting smaller </garnt>
<garnt> yeah and I also I have to say it's great </garnt>
<garnt> seeing the way people react to the way </garnt>
<garnt> Japanese people react to other people </garnt>
<garnt> because I can imagine when you go to </garnt>
<garnt> America people are surprised when you say </garnt>
<garnt> Japanese people are kind to us because you </garnt>
<connor> see like you see like on your videos like </connor>
<connor> you know like you saw [ __ ] like you see </connor>
<connor> some of the stuff that you see in the media </connor>
<connor> about America and then you get here and </connor>
<joey> you're like oh </joey>
<joey> no there's some good people in America </joey>
<joey> there's some good people everywhere yeah </joey>
<connor> I mean there's some bad people everywhere </connor>
<connor> but Japan is a country that is almost </connor>
<connor> completely devoid of bad people I feel </connor>
<joey> like it's an anomaly in the </joey>
<connor>  of the world right where I don't </connor>
<connor> really feel like you have to worry about </connor>
<connor> safety or anything like that </connor>
<connor> I mean obviously it's always good to be </connor>
```

### Prefix 3

```
<joey> take for granted in terms of how you </joey>
<joey> know like the way the country functions </joey>
<joey> for sure like you know when you get </joey>
<joey> asked like the littlest thing for every </joey>
<garnt> thing that kind of like adds up and adds </garnt>
<connor> up and adds up yeah every single time </connor>
<joey> yeah they asked me especially if your </joey>
<joey> dad is asking what beer this is </joey>
<joey> um like they had cover charge in one </joey>
<connor> place because current charge is pretty </connor>
<connor> common in Japan yeah yeah 500 to 1000 </connor>
<connor> yen you get a snack or something and my </connor>
<connor> dad was like did I did I get scammed and </connor>
<joey> I was like no no it's </joey>
<connor> it's normal but it uses on guard with </connor>
<joey> everything yeah yeah like an ATM he's </joey>
<joey> like is that ATM safe and I was like </joey>
```

True Completion:

```
<joey> they're all safe every ATM's safe I mean </joey>
<joey> I get where it's concerned because it's </joey>
<joey> not all safe yeah I told him I'm like </joey>
<garnt> everything's safe here don't worry like </garnt>
<connor> anything it's all good it's all safe no </connor>
<garnt> one's trying to scam you no one's trying </garnt>
<garnt> to do anything Japan's probably well </garnt>
<garnt> like one of the countries in Asia where </garnt>
<garnt> you can feel most at home feeling safe </garnt>
```

GPT2-Small:

```
<connor> no it is it's okay so I'm like it's not </connor>
<garnt> like a safe place to sell my beer yeah </garnt>
```

GPT2-Med:

```
<joey> yeah it's okay he's like he's like </joey>
<joey> is this ATM safe because if you </joey>
```

Bloom 560:

```
<joey> because it's very like the most </joey>
<joey> foreign language I'd say yeah I mean </joey>
<joey> they ask a lot of questions about </joey>
<joey> everything okay yeah I was like oh </joey>
<connor> well I'm like uh I can't speak any </connor>
<connor> other language but uh my dad can speak </connor>
<connor> English yeah yeah I don't really </connor>
<connor> understand his life so I was like oh </connor>
<connor> okay fine I'll just talk to him I'll </connor>
<connor> just talk to him I'll just talk to him </connor>
<garnt> yeah and then yeah I remember I was </garnt>
<garnt> like why was he asking for a drink </garnt>
<garnt> for one night because his dad was like </garnt>
<garnt> how do you do you want to buy a drink </garnt>
<garnt> and he was like oh how do you do you </garnt>
<garnt> want to buy a drink and I was like </garnt>
<garnt> well I guess I'll just go to the </garnt>
<joey> nearest ATM and take them out and then </joey>
<joey> just buy a drink from the drink machine </joey>
<joey> and then I'll just go back home just </joey>
<joey> buy a drink from the ATM and I was </joey>
<joey> like what do you mean yeah that's how </joey>
<joey> much effort does it take to be like </joey>
<joey> I want to buy a drink and then go back </joey>
<joey> home to take them out and then buy a </joey>
<garnt> drink from the machine and then I'm like </garnt>
<garnt> how do you do you want to go to the </garnt>
<garnt> ATM and then yeah yeah you just go to </garnt>
<garnt> the next one and then just take out the </garnt>
<garnt> other one and then you have to take out </garnt>
<garnt> the  like it takes like an hour </garnt>
```

LLaMA 7B:

```
<garnt> yeah you know I mean they don't </garnt>
<garnt> have a lot of crime in Japan yeah </garnt>
<joey> you know it's a lot of like the </joey>
<joey> people that do crime they're usually </joey>
<joey> foreigners who are the foreigners who are </joey>
<joey> foreigners who are the foreigners who </joey>
<joey> are the foreigners who are foreigners </joey>
<joey> yeah yeah yeah so it's like a lot of it </joey>
<joey> is just like the foreigners who are </joey>
<joey> coming in from like other countries in </joey>
<connor> japan yeah yeah and yeah I'm sure there </connor>
<connor> are Japanese people who do it as well </connor>
<connor> I mean I've seen it happen to Japanese </connor>
<joey> people as well yeah yeah yeah but I </joey>
<connor> don't think it's nearly as common yeah </connor>
<joey> I mean I mean I was like the only </joey>
<joey> foreigner there but I was like the only </joey>
<joey> foreigner there that wasn't like a </joey>
<joey> backpacker yeah yeah so it's like I </joey>
<joey> mean it's like the only foreigner that </joey>
<joey> was like it was like a business </joey>
<connor> professional foreigner </connor>
<joey> yeah yeah yeah so I was like the only </joey>
<joey> foreigner who wasn't like a backpacker </joey>
<connor> yeah yeah so it's like so it's like </connor>
<connor> it's like it's it's a very different </connor>
```

### Prefix 4

```
<joey> if you're sitting in the front seat just </joey>
<garnt> grab just stop playing Tic-Tac-Toe yeah </garnt>
<garnt> your move </garnt>
<garnt> yeah but no like uh like I guess it was </garnt>
<garnt> like the nihongo josu is kind of like </garnt>
<garnt> most of the time just like conversation </garnt>
<garnt> starter do Japanese people find it as </garnt>
<garnt> endearing when we just start speaking I </garnt>
<connor> always do I always win eigo josu to </connor>
<garnt> do them as well yeah oh really yeah yeah </garnt>
<connor> oh and I've said I do now I've started </connor>
<connor> doing it everywhere yeah do Japanese </connor>
<garnt> people find it as endearing when we </garnt>
```

True Completion:

```
<joey> speak broken ass Japanese be like ah I </joey>
<joey> think so bearded ah oh dude Japanese </joey>
<garnt> people </garnt>
<connor> they love that [ __ ] even if they don't </connor>
<connor> it's like I think they just prefer it </connor>
<joey> right like yeah yeah I think I think in </joey>
<joey> in a lot of minds of Japanese people </joey>
```

GPT2-Small:

```
<garnt> start speaking to them </garnt>
<garnt> that's just because I've actually </garnt>
<connor> just gotten used to talking to Japanese people </connor>
<connor> and I've just gotten used to saying </connor>
<connor> Japanese words and it's just been like </connor>
<connor> it's just been like this is how </connor>
```

GPT2-Med:

```
<garnt> literally just start talking and they </garnt>
<connor> are like oh yeah yes </connor>
<garnt> yeah I feel like it's a very </garnt>
<joey> normal Japanese conversation yeah I mean </joey>
<joey> it's not that you know it's not that </joey>
<joey> you know normal Japanese conversation </joey>
```

Bloom 560:

```
<garnt> start outtalking like and then yeah I </garnt>
<garnt> always get up to the microphone and just </garnt>
<garnt> be like yeah yeah I I don't give a </garnt>
<connor> [ __ ] about you guys this is weird I </connor>
<connor> don't know anyone who's ever tried to </connor>
<connor> do it yeah yeah I mean </connor>
<garnt> I don't know there's lots of like </garnt>
<garnt> different ways to do it but I mean like </garnt>
<garnt> that kind of like that kind of like </garnt>
<garnt> it's like it's like a lot of like </garnt>
<garnt> traditional places are like oh we </garnt>
<garnt> have </garnt>
<garnt> traditional Japanese like way of doing </garnt>
<garnt> it and it's kind of like so much of </garnt>
<garnt> like a lot of like traditional and </garnt>
<garnt> traditionalized Japanese way of doing it </garnt>
<garnt> and just like the way that you just </garnt>
<joey> go from like the most traditional way </joey>
<joey> to just get up to the microphone and just </joey>
<joey> be like yeah yeah yeah yeah yeah yeah </joey>
<joey> and and and you know Japanese people </joey>
<joey> yeah they're always always like that </joey>
<joey> yeah yeah yeah yeah yeah yeah yeah </joey>
<connor> it's like so weird because you know </connor>
<connor> you know like you know when you go to </connor>
<connor> like a traditional temple and you </connor>
<connor> hear the traditional way of doing it </connor>
<connor> and you just like the traditional </connor>
<connor> way and then you just kind of start </connor>
<garnt> watching like traditional Japanese TV </garnt>
<garnt> shows and the most you get to experience </garnt>
<garnt> is like I don't know when it is like </garnt>
<garnt> it's not like it's not like a </garnt>
<garnt> traditional like traditional </garnt>
<garnt> temple but like a traditional like </garnt>
<garnt> traditional temple that you feel is </garnt>
<garnt> like the most traditional kind of </garnt>
<garnt> traditional way of doing it but like </garnt>
<garnt> I mean like there's some other ways </garnt>
<garnt> as well that you can do it but like </garnt>
<garnt> for me it's like it's like a different </garnt>
<garnt> type of like uh kind of like uh </garnt>
<garnt> traditional    </garnt>
```

LLaMA 7B:

```
<garnt> start speaking English yeah I don't </garnt>
<connor> know because sometimes like </connor>
<garnt> sometimes it's just like oh yeah yeah </garnt>
<garnt> yeah yeah but sometimes it's like oh </garnt>
<garnt> okay yes let's talk about this </garnt>
<garnt> thing so yeah it's like it's kind of </garnt>
<garnt> it's a bit awkward because like </garnt>
<joey> like sometimes you just like you you </joey>
<joey> just start talking to people yeah </joey>
<joey> but it's like it's like okay I want to </joey>
<joey> talk about this thing and sometimes </joey>
<connor> like you you have to like you have to </connor>
<connor> like like be like okay I'll talk about </connor>
<connor> this thing I want to talk about I want </connor>
<connor> to talk about this thing that I'm </connor>
<connor> interested in yeah it's like it's </connor>
<connor> like a bit scary because like I've </connor>
<connor> talked about me before on the podcast </connor>
<connor> like if you want to talk about a thing </connor>
<connor> I'm really into like you just you just </connor>
<connor> you know just like you just go for it </connor>
<connor> yeah yeah like that's fine yeah </connor>
<garnt> because I'm like for the most part like </garnt>
<connor> when I'm in a new place like if I'm </connor>
<connor> in a place where I don't know anyone </connor>
<connor> and I feel like I'm gonna be there for </connor>
```

### Prefix 5

```
<joey> yeah where you open the door and you </joey>
<joey> close the door to the taxi yeah but like </joey>
<joey> I was like do not touch the doors I know </joey>
<connor> you want to don't do it they will open </connor>
<connor> it for you so they they're kind of </connor>
<connor> getting used to it and stuff I don't get </connor>
<joey> it it's it's tough It's hard traveling </joey>
<joey> outside of Japan and unlearning that the </joey>
<joey> amount of [ __ ] times I've traveled </joey>
<joey> out and I've just for one second walk </joey>
<joey> straight out of an Uber and just not </joey>
<garnt> looked back yeah it's just it it happens </garnt>
<garnt> every single time I like I've had the </garnt>
<joey> opposite where like I walk up to the </joey>
<joey> Uber I'm just standing in front of it </joey>
<joey> just waiting for it to open I'm just </joey>
```

True Completion:

```
<joey> like oh yeah yeah right yeah yeah yeah </joey>
<connor> yeah </connor>
<garnt> um so they're getting used to it what uh </garnt>
<joey> what are you planning for to do with </joey>
<connor> them for like the rest of your time for </connor>
<joey> a few more days someone just came to </joey>
<joey> some nice restaurants </joey>
<garnt> golden guy uh I might I'm I'm do I I I </garnt>
<garnt> gotta stop drinking </garnt>
<garnt> my parents they like drinking so it's </garnt>
<garnt> like I'm like I'm like dying but no </garnt>
<garnt> drinking please </garnt>
```

GPT2-Small:

```
<garnt> waiting for it to open because I'm </garnt>
<garnt> just waiting for it to open and I'm </garnt>
<garnt> just like wait </garnt>
```

GPT2-Med:

```
<connor> waiting and I'm just like oh God no no </connor>
<connor> no no no you have to go in and out of </connor>
```

Bloom 560:

```
<joey> waiting for the Uber to open I'm like </joey>
<joey> [ __ ] I don't know what's going on I </joey>
<joey> don't know what the [ __ ] is going on </joey>
<joey> right now I don't know what the [ __ ] </joey>
<connor> this is gonna be so I'm waiting till one </connor>
<joey> thing happens and so I was like oh </joey>
<joey> oh I was going to go up to the door </joey>
<joey> and then yeah that's fine </joey>
<connor> I was like what the [ __ ] what's going on </connor>
<connor> what's going on there was one time </connor>
<connor> when I was like oh this is this is this </connor>
<connor> is really weird I was like I was like </connor>
<connor> what the [ __ ] is that and I got up to </connor>
<connor> the door and there was a like a big </connor>
<connor> window that was like there was a like </connor>
<connor> a big window with like a big </connor>
<connor> [ __ ] like a paved road and I was </connor>
<connor> like this is this is really weird I </connor>
<connor> was like do not do not do not do not </connor>
<connor> [ __ ] do not do not do not do not do </connor>
<connor> anything please please and so I sat on </connor>
<connor> the desk and the desk was like oh [ __ ] </connor>
<connor> and uh I was like no no no no no no </connor>
```

LLaMA 7B:

```
<joey> staring at the door and I'm just like </joey>
<joey> I'm just standing there for 10 minutes </joey>
<joey> and then I'm just like oh I guess I'm </joey>
<joey> supposed to open the door </joey>
<joey> I'm trying to get out of this Uber and it </joey>
<joey> just won't open its just like it won't </joey>
<joey> open its like just give us the money </joey>
<joey> just give us the money </joey>
<joey> it's just like it's just not </joey>
<joey> opening the door and it's just like </joey>
<joey> just give us the money and I'm just </joey>
<garnt> like what the [ __ ] </garnt>
<garnt> I don't know what the [ __ ] </garnt>
<garnt> is going on here I just I just I just </garnt>
<garnt> I just [ __ ] it </garnt>
<garnt> it's like it's like I don't know what </garnt>
<garnt> the [ __ ] I just it's so annoying </garnt>
<joey> because the Uber driver is like just </joey>
<joey> standing there waiting </joey>
<joey> I'm like what what's going on </joey>
<joey> this is a taxi it's like the taxi </joey>
<joey> is trying to tell me what to do </joey>
```

## Open ended generation

Note that each generation separated by a line break is independent of each other.

### GPT2-Small

```
<garnt> Yeah. </garnt>
<joey> - I did watch it and I
really enjoyed it. </joey>
<garnt> I'm just like, this is just so good. </garnt>
<connor> - I think, I think I've
tried it all on like a budget. </connor>
<connor> Like I've watched the
biggest Marvel movie of all time, </connor>
<connor> which was probably like the
last big Marvel movie, </connor>
<connor> which is not even in the top 10 </connor>
<garnt> but I've watched the
biggest Marvel movies of all time. </garnt>
<garnt> And, it was just the first
time in my life that I watched </garnt>
<garnt> something that I could not fucking relate to, </garnt>
<garnt> because I've really only
been into Marvel movies </garnt>
<garnt> that are like really big
and I'm, I feel like- </garnt>
<garnt> - The biggest Marvel movie of all time. </garnt>
<connor> - That is the biggest Marvel movie of all time. </connor>
<joey> - That is the most Marvel movie
I've ever seen at all. </joey>
<joey> - And I've also, I feel like you
just can't get into Marvel, </joey>
```

```
<connor> - The problem is that you have to put it, </connor>
<joey> you have to put the thing in. </joey>
<connor> And I had to put the thing in. </connor>
<garnt> And I just found it really weird, </garnt>
<garnt> because I was like, I
was just like, "Oh, okay, </garnt>
<connor> what's going on?" </connor>
<garnt> - Like you guys were like,
"Oh yeah, this is the thing." </garnt>
<garnt> - Yeah. </garnt>
<garnt> - Yeah, so I was like, oh, okay. </garnt>
<connor> When are we gonna have
another episode of Trash Taste? </connor>
<connor> Do we have another episode or not? </connor>
<connor> 'Cause we've got our new
episode, this one's out. </connor>
<connor> So let's wait for
the other one. </connor>
<connor> - Oh, we're gonna do that. </connor>
<connor> - We're gonna do that. </connor>
<connor> - Yeah, I hope so. </connor>
<connor> - But I don't know, </connor>
<connor> when would you like
make a new episode? </connor>
<connor> Maybe on Trash Taste, </connor>
<connor> maybe in like the future? </connor>
<connor> - Probably in the future. </connor>
```

```
<garnt> - [Garnt] Yeah.
- [Joey] Yeah. </garnt>
<joey> - I don't know, some people, </joey>
<connor> I think I've been on the
shower in the fucking hospital </connor>
<connor> for like two hours, I didn't get ill. </connor>
<connor> - Yeah, yeah, yeah. </connor>
<connor> - And it's just like, "Are you okay?" </connor>
<connor> Like, when I get ill, </connor>
<connor> I take four to five days off, right? </connor>
<connor> It's like, "Oh, that's just so weird." </connor>
<connor> But the only thing that keeps me awake </connor>
<connor> is that sometimes I
try and sleep at night, </connor>
<connor> by like trying and sleeping at the same time. </connor>
<garnt> But it's like, I don't like it. </garnt>
<joey> I feel like I'm just not
gonna get better sleep </joey>
<joey> because I'm already tired. </joey>
<connor> - Yeah. </connor>
<joey> - And then I'm just like, "Yeah," </joey>
<joey> I'm like, "Oh, I'll take a day off now." </joey>
<joey> - Exactly. </joey>
<connor> - And then I get up. </connor>
```

```
<joey> - [Connor] Oh, I don't know. </joey>
<garnt> - No, no you do but you're
not a person to talk about it. </garnt>
<connor> - I mean, it's not- </connor>
<garnt> - It's not a thing to talk about. </garnt>
<garnt> - Yeah, that is. </garnt>
<connor> - It's not a thing to talk about. </connor>
<connor> - I mean, at least on a
lot of the other shows I've seen, </connor>
<garnt> there are so many shows that
they just don't know about. </garnt>
<garnt> - Yeah, but you know, </garnt>
<garnt> because it's not, it's not like, </garnt>
<garnt> it's not like a big show as much as, </garnt>
<joey> you know, "Domestic Girlfriend" or something. </joey>
<connor> - Yeah, yeah, exactly. </connor>
<joey> - [Connor And Joey] Yeah, yeah. </joey>
<connor> - It's not like a big show </connor>
<connor> that's just like, let's
say, a couple of seasons in. </connor>
<connor> - Yeah, yeah. </connor>
<connor> - That's the thing, right? </connor>
<connor> But like I feel like, </connor>
<connor> especially at the end of
"Domestic Girlfriend," </connor>
```

```
<joey> - I think he was in a really big one. </joey>
<garnt> - I think it was like 10 or
10, 15 minutes into it. </garnt>
<garnt> - [Garnt] Yeah. </garnt>
<connor> - I think he's like on one of those </connor>
<connor> like, I dunno what it is. </connor>
<garnt> - Yeah, he was like, "Can you
tell me, a guy who's like, </garnt>
<joey> "I don't know anyone in my
life who can speak Japanese." </joey>
<joey> - [Joey] Yeah. </joey>
<garnt> - And I was like, oh,
he doesn't speak Japanese. </garnt>
<garnt> And he's like, "Can I speak?" </garnt>
<garnt> And I'm like, "I don't know." </garnt>
<joey> And I'm like, "Can you tell me
that you can speak Japanese? </joey>
<garnt> You'd have to be the other way around. </garnt>
<joey> And I'm like, "I don't know
a Japanese person, </joey>
<joey> I'm like, "That sounds weird." </joey>
<joey> And so I'm like, "I need to talk to you." </joey>
<joey> And he's like, "Oh, he's a YouTuber. </joey>
<garnt> I need to talk to you man." </garnt>
```

### GPT2-Med

```
<garnt> - I don't think I've ever been. </garnt>
<joey> - I mean, there's no reason for you to. </joey>
<garnt> - I've been to plenty of countries </garnt>
<garnt> where the food was good </garnt>
<garnt> and I just didn't enjoy it. </garnt>
<connor> I think I should go back to the UK. </connor>
<garnt> - I want to go back. </garnt>
<garnt> - I want to go back as well. </garnt>
<joey> I wanted to go back to the UK. </joey>
<joey> - I want to go back. </joey>
<joey> - The food was very good. </joey>
<joey> Like I used to cook a lot in the UK, </joey>
<joey> but I feel like I just can't cook </joey>
<joey> enough to get by. </joey>
<joey> - That's true. </joey>
<joey> - I don't have the
energy to cook enough </joey>
<joey> to get by. </joey>
<joey> - Do you think I'm the exception? </joey>
<joey> - I think I am. </joey>
<joey> - Yeah, you think I am? </joey>
<joey> - I think so. </joey>
<garnt> Because I can't cook enough
to be able to eat that much. </garnt>
```

```
<connor> - I am. </connor>
<connor> You can't say anything. </connor>
<joey> - I can't say anything. </joey>
<garnt> - Yeah, you can't say anything. </garnt>
<garnt> You just have to sit there. </garnt>
<garnt> - Yeah, you can't say anything. </garnt>
<garnt> - But like if you do that </garnt>
<joey> and you're like, I'm a JoJo fan, </joey>
<joey> I'm gonna say that. </joey>
<joey> - I mean, I think, you know, </joey>
<joey> - Yeah, but I mean, </joey>
<joey> - I think you should, you know, </joey>
<joey> - Especially if you're
sitting next to each other. </joey>
<connor> - Yeah, exactly. </connor>
<joey> - Like if you're like, you know, </joey>
<joey> you're sitting next to
each other and you say it, </joey>
<joey> and they're like, oh yeah,
I'm a JoJo fan, yeah. </joey>
<joey> I'm gonna say it, I'm a JoJo fan. </joey>
<joey> And I'm like, well, I'm
not gonna say it. </joey>
<joey> - Yeah, I mean, </joey>
<joey> - I mean, I'm not gonna say it. </joey>
<joey> - I'm not saying it, </joey>
```

```
<connor> - Yeah.
- Yeah. </connor>
<joey> - Did you ever try to join
like the "Trash Taste" </joey>
<joey> or did you just like, you
never joined the "Trash Taste"? </joey>
<joey> - No, I never joined the
Trash Taste at all. </joey>
<joey> I didn't even know it existed. </joey>
<connor> - You didn't know it existed. </connor>
<connor> - You didn't know it existed? </connor>
<joey> - I don't think I've
seen a single episode </joey>
<joey> of "Trash Taste" since "Trash Taste," </joey>
<joey> I was like, why is there this? </joey>
<garnt> - Yeah.
- And then I started </garnt>
<garnt> going on "Trash Taste" for
the first time on my channel. </garnt>
<garnt> And it was the first
time I watched like, </garnt>
<garnt> I think I watched about four episodes. </garnt>
<garnt> - Four episodes.
- Yeah. </garnt>
<garnt> - And I knew it was gonna be good. </garnt>
<garnt> And then I watched it and I
thought it was pretty good. </garnt>
<garnt> It was pretty good, and
I was like, this is pretty good, </garnt>
```

```
<connor> - I was like, "Why is it so hard, </connor>
<connor> to get into the Olympics?" </connor>
<connor> You know what I mean? </connor>
<garnt> It's like, "Is it really worth it?" </garnt>
<garnt> Like, I don't know. </garnt>
<garnt> I don't know if I'm
getting old and retired </garnt>
<garnt> or whatever. I don't know. </garnt>
<garnt> 'Cause I can imagine I've
never been to an Olympics </garnt>
<garnt> other than the Olympics, but
that's because I've been to </garnt>
<garnt> the Olympics before. </garnt>
<garnt> - Yeah, yeah. </garnt>
<garnt> - And I'm like, I don't
really feel like an outsider. </garnt>
<connor> I don't feel like an outsider. </connor>
<connor> I feel like I'm part of the
team and I need to support </connor>
<connor> and it's like, how can this be? </connor>
<connor> Like, how? </connor>
<connor> Like, how does it not make sense? </connor>
<connor> Like, how does it even feel
like an Olympics to you? </connor>
<connor> Like, I feel like I'm part of
the team and I need to support </connor>
```

```
<connor> cause we're just gonna go ham. </connor>
<connor> And we're like, what if we
do this again? What if we, </connor>
<connor> what if we just do this
again and then we just do it </connor>
<joey> and then we're just gonna
get more people to do it. </joey>
<joey> - Yeah.
- And then you know </joey>
<connor> it's in its prime and it's
just gonna continue to grow. </connor>
<connor> But I think the thing that
really, really blew me away </connor>
<connor> about "Trash Taste" was
just how much the "Trash Taste" </connor>
<garnt> have grown over the years, right. </garnt>
<joey> - I'm not gonna lie, I've
never thought about it </joey>
<joey> in terms of like "Trash Taste"
like that because it's- </joey>
<garnt> - It's literally just a
show for people who don't watch </garnt>
<garnt> anime and don't watch "Trash Taste." </garnt>
<garnt> - Exactly, exactly. </garnt>
<garnt> - It's basically just a show
where we talk about anime </garnt>
<garnt> with people who don't watch anime. </garnt>
```

### Bloom 560M

```
<connor> - Okay. </connor>
<connor> - It's like an easy game. </connor>
<connor> You just like, when you
want to play the game, </connor>
<connor> and you have free time, </connor>
<connor> you just start playing it, </connor>
<connor> and then you just kind of
turn on your brain, right? </connor>
<connor> You're just like, okay,
I'm having a good time </connor>
<garnt> playing that game now. </garnt>
<garnt> - Yeah like, </garnt>
<joey> I'm like, you know what? </joey>
<joey> I could probably be playing, </joey>
<joey> like some kind of challenging game. </joey>
<joey> Like I've recently been
playing some kind of game </joey>
<joey> that's like really challenging, </joey>
<connor> like the Pokemon game. </connor>
<connor> Like I really wanna play that. </connor>
<connor> I want to do that. </connor>
<connor> I want to, like, </connor>
<connor> I want to do that in the long run. </connor>
<connor> But like, </connor>
<connor> how long is the game gonna
take me to get to that point? </connor>
<connor> - [Joey] Yeah. </connor>
<connor> - I mean, like I have
found a way to be like, </connor>
<connor> I can beat Pokemon in a long time. </connor>
<connor> And I don't know if that's just me, </connor>
<connor> but at least every time
I've beat Pokemon in a long </connor>
<connor> time, I'm just like, okay, </connor>
<connor> well I just know I can beat it. </connor>
<connor> And then I play it, and
then I'm just like, </connor>
<connor> I just can't beat it anymore. </connor>
<connor> And then I just kind of
turn on my brain.(laughing) </connor>
<connor> - It's like, I had this
thought the other day, </connor>
<connor> and I was like, what if
I'm just like actually, </connor>
<connor> like getting into the game, </connor>
<connor> and I'm just like this
like, I don't know, </connor>
<connor> like I don't know if
it's just me or my brain, </connor>
<connor> but I guess I just kind of realized, </connor>
<connor> oh, maybe I just do
this for fun.(laughing) </connor>
<connor> Maybe I'm just playing it. </connor>
<connor> - I mean like, </connor>
<connor> you know, I don't really
give a shit about Pokemon, </connor>
<connor> but I feel the Pokemon game
is kind of the same thing. </connor>
<connor> Where the more you get into it, </connor>
<connor> the more you get into the
game and the more you just, </connor>
<connor> you think, I could do this,
and I could do this all day. </connor>
<connor> I can do this all day. </connor>
<connor> But I guess, </connor>
<connor> as a content creator, what's
the game to get invested in? </connor>
<connor>        </connor>
<connor>     </connor>
<connor>   I mean, </connor>
<connor> I think Pokemon is the same
thing, I just don't understand. </connor>
<connor> - I think it's the same thing. </connor>
<connor> -   </conno>
<connor> -  What     </conno>
<joey>           </joey>
<connor>            </conno>
<joey>             </joey>
<connor>            </conno>
<connor>              </conno>
<joey>                                                                                                                      </                                                                                                                                                                                     </joey>
<joey> - I don't know. </joey>
<joey> I don't know. </joey>
<joey> I just feel like there's
so much to talk about. </joey>
<joey> Just like a lot of things to talk about </joey>
<joey> and a lot of, I don't know. </joey>
<garnt> - The amount of time </garnt>
<garnt> I've spent on the internet
has just just like, </garnt>
<garnt> it's way more than I
thought it would be actually. </garnt>
<garnt> - [Joey] Yeah. </garnt>
<connor> - And I think that's because of the way </connor>
<connor> you think about it. </connor>
<joey> - Yeah, I mean, I think
that's just the way </joey>
<joey> we view our time. </joey>
<connor> - I think it's just the way </connor>
<connor> we view our time on the internet. </connor>
<connor> It's just like, it's so much more. </connor>
<connor> - I don't know. </connor>
<connor> I feel like there's a
bunch of things that I don't know. </connor>
<connor> I mean, you know, </connor>
<connor> you say you're a monkey, but you know, </connor>
<connor> it's like a lot of things,
like, you know, for example, </connor>
```

```
<joey> and so I was sitting there
on the desk reading my phone </joey>
<joey> and I was like, "Oh, okay, </joey>
<joey> how about we just read the
same thing for each other? </joey>
<joey> Like, just let's do it." </joey>
<joey> And so I was like, "Oh, okay." </joey>
<joey> I'm like, "Okay, yeah, I
definitely don't need it." </joey>
<joey> But I'm like, I have no
interest in doing it. </joey>
<joey> - Yeah. </joey>
<joey> - So I just kept, I had no
interest in doing it, </joey>
<garnt> 'cause it was like, (coughing) </garnt>
<garnt> it was like a five page
A4 document, right? </garnt>
<garnt> - [Joey] Yeah. </garnt>
<garnt> - I don't wanna read it. </garnt>
<garnt> - [Joey] Yeah. </garnt>
<garnt> - And so I just kept reading it </garnt>
<garnt> and I was just like, </garnt>
<garnt> I was like, "Oh, okay." </garnt>
<garnt> And then I was just like, </garnt>
<garnt> "So I just want to know
what's going on here?" </garnt>
<garnt> - [Joey] Yeah. </garnt>
<garnt> - And then I was like, </garnt>
<garnt> "Okay, it's not gonna
be so much of a hassle </garnt>
<garnt> "but I want to know what
the fuck's going on here." </garnt>
<garnt> So I go to Google translate </garnt>
<garnt> and I look up what the
exact page is on Google translate </garnt>
<garnt> and Google translate tells
me exactly what the page is </garnt>
<garnt> on Google translate, right? </garnt>
<garnt> And so I was like, "Oh." </garnt>
<garnt> - [Garnt] Okay. </garnt>
<garnt> - I was like, "Okay, okay." </garnt>
<garnt> I was like, "Oh, okay," right. </garnt>
<garnt> And then I couldn't get it
done because I was like, </garnt>
<garnt> "I don't know what the fuck
is going on here, right?" </garnt>
<garnt> And so I was like, "I
just want to know what </garnt>
<garnt> "the fuck is going on here." </garnt>
<garnt> So I go to Google translate, </garnt>
<garnt> and it tells me what the
exact page is on Google translate </garnt>
<garnt> and Google translate tells
me exactly what the page is </garnt>
<garnt> and I was like, "Oh, okay." </garnt>
<garnt> And then I couldn't get it done. </garnt>
<garnt> And I was like, </garnt>
<garnt> I was like, "I don't know
what the fuck is going on here. </garnt>
<garnt> "I just want to know what's going on here." </garnt>
<garnt> And then I go to Google translate, </garnt>
<garnt> and ugh, I was getting it done. </garnt>
<garnt> - [Joey] Okay. </garnt>
<garnt> - I was like, (coughing). </garnt>
<garnt> And I was like, (coughing). </garnt>
<garnt> - [Joey] ugh. </garnt>
<garnt> - I was like, </garnt>
<garnt> I was like, (coughing), and I was like, </garnt>
<garnt> "Please, please help me." </garnt>
<garnt> ugh, I was like, "What the fuck" </garnt>
<garnt> and like, I was trying to
look ugh in my ugh ugh in ugh. </garnt>
<garnt> ugh, ugh, ugh, ugh, ugh, ugh, ugh, ugh, ugh, </garnt>
```

```
<connor> - Yeah, I mean, I guess that
means you can leave it </connor>
<connor> for longer if you want. </connor>
<garnt> - Yeah, I mean, I guess
that sounds like a cool idea </garnt>
<garnt> to you where you just like
drop the whole thing down </garnt>
<joey> and just leave it to the
people who know, you know, </joey>
<joey> who are familiar with this
and want to keep this. </joey>
<connor> - Yeah, I mean, I feel like </connor>
<connor> you should be fine with that, </connor>
<connor> but you know, </connor>
<connor> I feel like you should
just be fine with them </connor>
<connor> having your stuff and
not letting people do it. </connor>
<connor> Yeah. I mean, you know, </connor>
<connor> it's a little bit weird </connor>
<garnt> if you're doing something
like that with YouTube, </garnt>
<garnt> but I feel like that's
the right way to go about it. </garnt>
<garnt> - Yeah. </garnt>
<garnt> - You know, that's, that's
what makes it interesting. </garnt>
<garnt> - It is interesting. </garnt>
<garnt> - And I feel like, you know, </garnt>
<garnt> it's something entirely new, </garnt>
<garnt> and you know, I feel
like being an outsider </garnt>
<garnt> in this kind of like
intervention, you know, </garnt>
<garnt> it's a little bit different
to what you have to do </garnt>
<garnt> to be an outsider. </garnt>
<garnt> But I know that a lot of
YouTubers, you know, </garnt>
<garnt> especially when you are on
the internet, you know, </garnt>
<garnt> have a lot of free time. </garnt>
<connor> - I know a lot of YouTubers </connor>
<connor> who have a lot of free
time where they work </connor>
<connor> on some of the videos </connor>
<connor> and they get to do certain things. </connor>
<connor> And you know, </connor>
<connor> when you have a lot of free time, </connor>
<connor> I feel like, you know, </connor>
<connor> there is a lot of people who are like, </connor>
<connor> yeah, I'm just gonna do my own thing. </connor>
<connor> I don't need to worry about this. </connor>
<connor> I'm just gonna do my own thing. </connor>
<connor> And then there's people, </connor>
<connor> when they're on the internet,
who are like, oh, </connor>
<garnt> this is me, this is my
free time, I'm gonna do it. </garnt>
<garnt> And then there's just like, </garnt>
<garnt> you know, there's a
lot of people who are like, </garnt>
<garnt> yeah, I'm just gonna do my own thing. </garnt>
<garnt> I'm not gonna worry about it. </garnt>
<garnt> I'm just gonna do my own thing. </garnt>
<garnt> Yeah, this is what I like, </garnt>
<garnt> this is what I'm like, this
is what I like doing. </garnt>
<garnt> You know what I mean? </garnt>
<garnt> - Yeah, exactly. </garnt>
<connor> - But I feel like, I feel like </connor>
```

```
<joey> - Well, it depends on the song. </joey>
<joey> - Yeah, yeah. </joey>
<joey> - I think some songs are
just so fucking hard to listen to </joey>
<joey> that it's just like, okay,
this is an album. </joey>
<joey> It is a fucking amazing album. </joey>
<connor> But the problem is is that, you know, </connor>
<connor> you can kind of be like, okay, </connor>
<connor> this is an amazing fucking album </connor>
<connor> but the problem is is that
it just feels like a mediocre </connor>
<connor> album, right? </connor>
<joey> It's like, it's not great. </joey>
<joey> - Yeah, I mean, I think like,
I feel like that's a good </joey>
<joey> place to end it. </joey>
<joey> I like the music a lot but I
feel like it's just a mediocre, </joey>
<joey> like a mediocre album. </joey>
<joey> And it's just like, it's
just like, I don't know. </joey>
<joey> I don't really like it. </joey>
<joey> It's one of those albums where I know </joey>
<joey> I like the music but I
feel like the lyrics, </joey>
<joey> especially the lyrics to
like "Don't Understand Me" </joey>
<joey> and I feel like it's
probably the best song </joey>
<joey> in like "86" or something. </joey>
<joey> I didn't know what was going on. </joey>
<connor> - Yeah, I mean, it's the
same way with a lot of, </connor>
<connor> like, you know, </connor>
<joey> you can listen to a
fuckton of songs with lyrics </joey>
<joey> and like, and you can understand
what they're saying, </joey>
<joey> but like, some of the songs
that are just so fucking hard </joey>
<joey> and you can't really
understand them in a way </joey>
<joey> that's so subtle and so
like, unnerving and just like, </joey>
<joey> so depressing, you know,
that they just, you know, </joey>
<joey> it's like there's a sadness
or there's a morbidness </joey>
<joey> that comes out of like the song. </joey>
<joey> And I feel like the reason
I love this album is that </joey>
<joey> the lyrics are so fucking
concisive and just so subtle. </joey>
<joey> And I feel like, I don't
know why I love this song. </joey>
<joey> I love the fact that it
always has the most, </joey>
<joey> it always has the most
concisive lyrics. </joey>
<joey> I love that. </joey>
<joey> I love that. </joey>
<joey> - It's like, "Oh, he's a teacher." </joey>
<joey> - It's like, "Oh, he's an
idiot" or something like that. </joey>
<joey> - I love that. </joey>
<joey> (all laughing) </joey>
<joey> And I love how, like, </joey>
<joey> he just kept using the word
idiot in the same way </joey>
<joey> where it's like, "idiot." </joey>
<joey> And I love how he just
kept using the word like, </joey>
<joey> "And then he goes, "Oh
cool, but then he goes, </joey>
<joeey> "but then he goes, "Oh, what
the fuck is going on here?" </joeey>
```

```
<connor> - It's like the only
time you can do it. </connor>
<joey> - You're the only person
who can do it just like. </joey>
<joey> - It's like the only time
you can do it, but it's like, </joey>
<joey> I think there are other things that you can do </joey>
<joey> that are much more fun
and more relaxing. </joey>
<joey> - Yeah. </joey>
<joey> - I can do like a climbing
and like a climbing thing. </joey>
<joey> 'Cause I like climbing. </joey>
<joey> - Yeah, I do like a climbing. </joey>
<connor> - I can do like a climbing
and climbing special. </connor>
<joey> - Yeah.
- Yeah. </joey>
<joey> - I like climbing a lot. </joey>
<joey> - I like climbing as well. </joey>
<joey> - Yeah, but like, I don't
really want a climbing thing. </joey>
<joey> - Yeah, because you just go up. </joey>
<joey> - I do, I do. </joey>
<joey> - But like, I like climbing
a lot of things, I like, </joey>
<joey> I mean, I did like a climbing thing </joey>
<joey> but it was quite expensive. </joey>
<joey> - I did a climbing thing. </joey>
<joey> - I did a climbing thing </joey>
<joey> and that was the only
time you could do it. </joey>
<joey> - I mean, that's the only
time I could do it. </joey>
<joey> I think I did like maybe like a climbing </joey>
<joey> like a climbing kind of thing </joey>
<joey> but I did it for like a week
and a half and I was like, </joey>
<joey> I need to do a stronger
thing for this one. </joey>
<joey> - I think you need to do
like a really really good </joey>
<joey> and long lasting thing to get
your body used to doing it. </joey>
<joey> - Yeah.
- Yeah, yeah. </joey>
<joey> - I'm not saying that
like a climbing special </joey>
<joey> is the most fun thing ever. </joey>
<joey> - I mean, I thought that
like a climbing special </joey>
<joey> was the most fun thing ever. </joey>
<joey> - I thought that when you do it, </joey>
<joey> it does the same thing that
a video game special </joey>
<joey> is the most fun thing ever. </joey>
<joey> - But like a video game
special is just like, </joey>
<joey> you get used to it. </joey>
<joey> - That's what I do for video
games, you know what I mean? </joey>
<joey> - Yeah. </joey>
<joey> - I can do it for like two weeks. </joey>
<joey> - I mean, normally I would like, </joey>
<joey> even if it wasn't a special, </joey>
<joey> I mean, I would like
do it anyway for video games </joey>
<joey> 'cause I don't know what the
fuck I'm doing with it. </joey>
<joey> But like I think the reason why I've like, </joey>
<joey> I can't do a lot of
like video game sports </joey>
<joey> is 'cause I've never been
able to do any in my life. </joey>
<joey> - Yeah. </joey>
<joey> - And just doing that, </joey>
<joey> I'm just like, I don't wanna
be doing a video game orto </joey>
<garnt> for like orto orto orto orto orto orto orto orto </garnt>
```

### LLaMA 7B

```
<connor> - What? </connor>
<connor> - Yeah, I mean, this is
like the thing that's like, </connor>
<garnt> - [Joey] You're gonna have to explain this. </garnt>
<connor> - Yeah, this is this
like, I don't know, </connor>
<garnt> - [Garnt] Yeah, what is this? </garnt>
<connor> - It's like, it's like
a Japanese game show thing. </connor>
<connor> - What? </connor>
<garnt> - Yeah, but the concept of it is that, </garnt>
<garnt> - What? </garnt>
<garnt> - Yeah, but the concept
of it is that, they're like, </garnt>
<connor> - Why? </connor>
<connor> - Yeah, so this is the concept of it, </connor>
<connor> they're like, "Okay, so this
is a Japanese game show </connor>
<connor> and it's like, "Okay, so
we've got these like, </connor>
<connor> "Okay, so we've got these
like, weirdos who are like, </connor>
<connor> "I'm gonna do this thing, right." </connor>
<connor> - [Garnt] What? </connor>
<connor> - Where it's like, </connor>
<connor> - What are you talking
about? </connor>
<connor> - It's like they're like, </connor>
<connor> "Okay, so we've got these
like four weirdos who are, </connor>
<connor> "Okay, so we've got these
four weirdos who are gonna </connor>
<connor> "do this task and then
the first one to do it </connor>
<garnt> wins a million dollars."
- What? </garnt>
<garnt> - Okay, so it's like, </garnt>
<connor> I don't know, I think
it's like a Japanese game show, </connor>
<connor> and then they're like, </connor>
<connor> "Okay, so they've got like, </connor>
<connor> "I don't know, they've got like, </connor>
<connor> "Okay, so they've got like, 100
people who are like, "Okay, </connor>
<connor> "I'm gonna do this task and
then the first one to do it </connor>
<connor> wins a million dollars." </connor>
<connor> And they've got like,
- What? </connor>
<connor> - And they've got like, </connor>
<connor> they've got like, 40, </connor>
<connor> - [Joey] What? </connor>
<connor> - And I guess it's
like this Japanese game show </connor>
<connor> thing where they've got like
four different tasks </connor>
```

```
<garnt> - I like that, I like the aesthetic. </garnt>
<connor> - Yeah, I like that too.
- Yeah, yeah. </connor>
<connor> - I think it's just cool. </connor>
<connor> - I think the problem is </connor>
<connor> that it's a lot of times,
it's just kind of like, </connor>
<connor> oh, cool, you're wearing a scarf with your shirt, </connor>
<connor> and it's like, oh, cool, </connor>
<connor> I'm gonna wear a scarf
with my shirt now as well. </connor>
<connor> - Yeah, yeah, exactly. </connor>
<connor> - It's just, it's like, </connor>
<connor> it's just like, yeah, yeah,
I'm gonna do that as well. </connor>
<connor> - And then you end up having </connor>
<connor> like three scarves on your neck, </connor>
<connor> and you look like a complete idiot, </connor>
<joey> 'cause no one would ever wear three scarves. </joey>
<connor> - I don't know, if I was
a rich person, I'd probably wear, </connor>
<connor> I'd probably wear like three scarves. </connor>
<connor> - I'd probably just wear one
scarf that was like, </connor>
<joey> really long and like,
you know, just like, </joey>
<joey> just like have that one scarf
that was like, oh, </joey>
<joey> it's like just like, you know, </joey>
<joey> you're just like, oh,
I'm just gonna wear this. </joey>
<connor> I'm just gonna wear it
until it gets old, </connor>
<connor> and then I'll probably
just have a scarf burning ceremony. </connor>
<connor> - I don't, I just don't know. </connor>
<connor> - I don't know. </connor>
<connor> I don't know.
- I don't know. </connor>
<joey> I think that's the only
reason why I don't wear one, </joey>
<connor> I think it's just like, </connor>
<connor> I don't know how to wear it right. </connor>
<connor> - I know how to wear it
right, I know I know how to wear it, </connor>
<connor> but I know that if I wear
a scarf, I'll end up with, </connor>
<connor> I'll end up looking like a fucking idiot, </connor>
<joey> so I don't want to risk it. </joey>
<joey> - So we didn't, so
we didn't have a scarf, </joey>
```

```
<connor> - Yeah, totally. </connor>
<connor> - It's like, you know, </connor>
<connor> it's like going to a restaurant </connor>
<connor> and you're like, you know, </connor>
<connor> if you order a steak, </connor>
<connor> you better fucking get steak. </connor>
<connor> And not like a hamburger, </connor>
<connor> you're like, you know, </connor>
<connor> you know, you don't just
get that, you know. </connor>
<connor> And that's like the same
thing with video games. </connor>
<joey> - Yeah.
- I think that's </joey>
<garnt> why some people get really
pissed off when the game </garnt>
<garnt> isn't up to par. </garnt>
<garnt> - Yeah, exactly. </garnt>
<garnt> Like if you're gonna
promise us, you know, </garnt>
<garnt> like, if you promise us </garnt>
<joey> that this is a brand new Nintendo game, </joey>
<joey> then, you know, </joey>
<joey> then that's what you should
be getting. </joey>
<joey> - Yeah. </joey>
<joey> - Exactly. </joey>
<joey> - And if, you know, </joey>
<joey> I'm not saying that like,
Nintendo has done this, </joey>
<joey> but, you know, </joey>
<joey> where they've kind of
like misled people into thinking </joey>
<connor> that they're getting a new game, </connor>
<connor> and then it turns out
it's just a remake, </connor>
<connor> or something like that. </connor>
<connor> - Yeah, yeah. </connor>
<connor> - And that's just, yeah, </connor>
<connor> I get why some people are mad. </connor>
<connor> But I think a lot of them
are just like, you know, </connor>
<garnt> there's a difference between
like a hype train, and a, </garnt>
<garnt> you know, a, you know,
something that's been, you know, </garnt>
<connor> promised to you. </connor>
<connor> - Yeah, yeah. </connor>
<connor> - Like, you know, </connor>
<connor> when people are like
hyped up for something, </connor>
<connor> you know, I think that's
a different level of, </connor>
<connor> you know, excitement to, </connor>
<connor> you know, I'm just hyped
because I'm hyped. </connor>
<connor> - Yeah, yeah. </connor>
<connor> - I was hyped for the
fucking Mario Kart 8 Deluxe. </connor>
<connor> Like, honestly, I was hyped for that, </connor>
<connor> I was hyped for that. </connor>
<joey> - Yeah, yeah, yeah, yeah. </joey>
<joey> - And I was hyped for that, but
I wasn't hyped for it </joey>
<. </joey>
<connor> to the point where I was thinking, </connor>
<connor> "If I don't get this, I'm gonna die." </connor>
<connor> - [Joey] Yeah, yeah, yeah. </connor>
<connor> - I wasn't like, </connor>
<connor> "If I don't get this, I'm gonna be a." </connor </ </ </ </. </ </ </connor </connor </connor
```

```
<joey> - I'll take that, yeah. </joey>
- Oh, no don't do that. </joey>
<connor> - I'll take that.
(both laugh) </connor>
<connor> - I've gotta stop
saying that, man. </connor>
<connor> I've gotta stop saying that. </connor>
<garnt> - When I'm gonna do that. </garnt>
<connor> - I've gotta stop saying that. </connor>
<connor> I'm gonna say that. </connor>
<connor> - I've gotta stop saying that. </connor>
<connor> - Well you can say that,
I'm gonna say it now. </connor>
<connor> - All right. </connor>
<connor> - You're gonna say it now. </connor>
<connor> - You're gonna say it now. </connor>
<connor> - I'm gonna say it now. </connor>
<joey> - Here we go. </joey>
<joey> We said it, we said it. </joey>
<connor> (all laugh) </connor>
<connor> - Yes, we said it.
(Joey laughs) </connor>
<connor> - You said it, you said it. </connor>
<connor> - We're all saying it. </connor>
<connor> (men laugh) </connor>
<connor> - I think that's it. </connor>
<connor> - I think that's it. </connor>
<connor> (men laugh) </connor>
<connor> - This is the first time
I've been able to say it. </connor>
<connor> - This is the first time
I've been able to say it. </connor>
<connor> - This is the first time
I've been able to say it. </connor>
<connor> - This is the first time
I've been able to say it. </connor>
<connor> - This is the first time I've been able to say it. </connor>
<connor> - This is the first time I've been able to say it. </connor>
<connor> - I've said it before, man. </connor>
<garnt> I've said it before. </garnt>
<connor> (Joey laughs) </connor>
<connor> - I've said it before.
(Joey laughs) </connor>
<connor> - Yeah, I've said it before. </connor>
<joey> But I've never been able to say it. </joey>
<connor> - I've said it before. </connor>
<garnt> - I've said it before. </garnt>
<garnt> - Yeah, yeah. </garnt>
<garnt> I've said it before, man.
- I've said it before. </garnt>
<garnt> - Yeah, I've said it before. </garnt>
<garnt> - Yeah, yeah, yeah. </garnt>
<garnt> - I've said it before, man. </garnt>
<connor> (all laugh) </connor>
<connor> - I've said it before, man. </connor>
<connor> (all laugh) </connor>
<garnt> - I've said it before.
(all laugh) </garnt>
<garnt> - I've said it before. </garnt>
<garnt> - I've said it before. </garnt>
<garnt> - Yeah, yeah, yeah. </garnt>
<garnt> - I've said it before, man. </garnt>
<garnt> (all laugh) </garnt>
<garnt> - I've said it before, man. </garnt>
<garnt> - I've said it before. </garnt>
<connor> (Joey laughs) </connor>
<joey> - I've said it before, man. </joey>
<garnt> - I've said it before. </garnt>
<joey> - I've said it before. </joey>
<connor> (Joey laughs) </connor>
<connor> - I've said it before.
(Joey laughs) </connor>
<connor> - I've said it before. </connor>
<garnt> (Joey laughs) </garnt>
<garnt> - I've said it before. </garnt>
<garnt> - I've said it before. </garnt>
<connor> (Joey laughs) </connor>
<jo and thn </. 20018 </. </ </. </..... </. </i>
```

```
<connor> That was my first experience of
like, "Oh, you know, </connor>
<joey> you can just have fun with
these two games, you know." </joey>
<garnt> - I mean, I think that's
why I really enjoyed Tetris. </garnt>
<garnt> I really enjoyed playing it
as a kid. I think it's just </garnt>
<garnt> because it was just fun. </garnt>
<garnt> - Yeah, it's fun. </garnt>
<connor> - It's a game where you don't have to </connor>
<connor> think. You just have to
just do the thing. </connor>
<connor> - Yeah, and it was a lot of fun. </connor>
<joey> - I think I learned to
play it first in the arcades </joey>
<joey> and I remember the
only thing I could do. </joey>
<joey> I would just keep going until
I ran out of lives, </joey>
<joey> and then I'd just go
back to the beginning. </joey>
<joey> And then I'd just do that,
just keep doing that, </joey>
<joey> and it was just the most
boring game to play. </joey>
<joey> And then I remember playing it at home, </joey>
<joey> and I remember it was
just so much harder </joey>
<joey> and then that's when I
just got to the point, </joey>
<joey> like, "Wow, you know, this
is actually kind of fun." </joey>
<joey> - I think I remember the
first time I played- </joey>
<joey> - Oh, man, I remember the first
time I played Tetris. </joey>
<joey> - Yeah.
- Yeah. </joey>
<joey> - I think I was maybe like
eight or nine years old, </joey>
<joey> and I had one of those
souvenir Tetris games. </joey>
<joey> I just remember, I remember
my grandma bought it for me </joey>
<joey> because she was like, </joey>
<connor> "I know I'm going to
spend a lot of time with you, </connor>
<connor> so just give me something to do. </connor>
<connor> You know, </connor>
<connor> Tetris is something you'll
probably enjoy, so buy this." </connor>
<connor> And I remember I was playing it, </connor>
<garnt> and I was just like, </garnt>
<garnt> "Oh, I got a little bit better at this. </garnt>
<garnt> I'm actually enjoying this." </garnt>
<garnt> And then I got to the point
where I realized, </garnt>
<garnt> "Oh, I'm actually good at this. </garnt>, </ </ </ </ </ </ </ </ </ </ </ </ </ </ </ </ </ </ </ g </ </ </ </ </ g </ g </ g </ garn </ garn e </ garn </ garn
```

## Prompted generation

Each model was prompted with the title: `<title> the differences between japanese and american people </title>`.

### GPT2-Small

```
<garnt> who are like trying to make it to america. </garnt>
<joey> - [Joey] Really? </joey>
<joey> - Yeah, because when I went to </joey>
<connor> the UK a few years ago, </connor>
<connor> and I remember being like, </connor>
<connor> "What's this thing called?" </connor>
<connor> And then they're so fucking good. </connor>
<connor> - [Garnt] Yeah. </connor>
<connor> - 'Cause they're like,
"Oh, we don't give a shit. </connor>
<connor> We just want to talk about it." </connor>
<joey> - No, because I remember going on </joey>
<joey> that flight from Japan to America, </joey>
<connor> and I was just like, "Oh, okay, </connor>
<connor> I'm gonna go to America." </connor>
<connor> And I was like, "Oh, okay, okay." </connor>
<connor> I was like, "Okay, well thanks for
supporting me on my way." </connor>
<connor> And then they're like, "We
have a flight to America." </connor>
<connor> And I'm like, "Yeah, I guess so." </connor>
<connor> And they're like, "Oh, fine." </connor>
```

```
<connor> and it's just like just the difference </connor>
<garnt> between japanese and american people </garnt>
<joey> right yeah right because like what </joey>
<joey> we're talking about is because </joey>
<joey> we're talking about here's a difference </joey>
<joey> that is so subtle that we don't really </joey>
<connor> know exactly what we're talking about because </connor>
<connor> we're talking about this difference between </connor>
<connor> japanese and american and like what does </connor>
<joey> japanese do to us and what does american do </joey>
<joey> to us and what does american do to us and </joey>
<joey> just like it's kind of like a very </joey>
<joey> different place to live in as well because </joey>
<joey> like this is like like a very different </joey>
<connor> place to live in Japan because </connor>
<connor> like the Japanese people live there </connor>
<connor> but it's kind of like a different </connor>
<connor> place to live in in Japan as well because </connor>
```

```
<joey> that I feel is very much like a separate </joey>
<connor> matter compared to the world of the
other countries that you go </connor>
<garnt> to as well you just go to these places </garnt>
<garnt> because there's a lot of different </garnt>
<garnt> cultures that exist in the world right </garnt>
<garnt> where one of them is like uh oh Japan </garnt>
<garnt> or Japan in general like there's a lot of </garnt>
<garnt> different cultures in every country </garnt>
<garnt> yeah but I feel like the world has </garnt>
<garnt> just become more of like a little bit </garnt>
<garnt> more open and like more open culture </garnt>
<garnt> because we've got so much more
open minded people now </garnt>
<joey> who are like really into japanese </joey>
<joey> culture right because it's like </joey>
<joey> it's like you can speak Japanese </joey>
<joey> but the Japanese people don't
really understand </joey>
<joey> Japanese culture and you're like you're </joey>
```

```
<joey> is that they speak a different language </joey>
<connor> than the Japanese one because </connor>
<connor> everyone speaks the same language and </connor>
<garnt> we can understand each other in the same </garnt>
<garnt> way that we can understand each other in </garnt>
<garnt> Japan and we can understand each other in the </garnt>
<garnt> same way that we can understand the </garnt>
<garnt> English and American we can understand </garnt>
<garnt> each other in the same way as we can </garnt>
<garnt> understand each other in the
same way but we can't </garnt>
<garnt> fully understand each other in the </garnt>
<garnt> same way that we can understand each other in </garnt>
<connor> the same way that we can understand each other </connor>
<connor> in the same way that we can understand each </connor>
<connor> other in the same way that we can understand </connor>
<connor> each other in the same way that we can </connor>
<connor> understand each other in the same manner </connor>
```

```
<garnt> is that they are like kind of </garnt>
<garnt> different, I don't know why. </garnt>
<garnt> They're all like different. </garnt>
<connor> - It's weird because
japanese people are like, </connor>
<connor> "Oh, you're a different country." </connor>
<connor> - Yeah, yeah. </connor>
<connor> But in Australia, it's just like, </connor>
<connor> we're like separate. </connor>
<connor> We have different accents, </connor>
<connor> but we all have different language. </connor>
<connor> - [Joey] Yeah. </connor>
<connor> - And the only time I ever heard </connor>
<connor> that, you know, British
people are like, </connor>
<connor> "Oh, you're a different country." </connor>
<joey> - It's true, but yeah, </joey>
<joey> but like it is a lot more
difficult to explain </joey>
<joey> to people who speak the same language. </joey>
<joey> Especially when it comes to
like, when you go back to Japan </joey>
```

## GPT2-Med

```
<garnt> and I'm just like there's some shit I'm </garnt>
<garnt> not getting yeah I'm just like </garnt>
<garnt> I don't understand </garnt>
<connor> because I don't want to go into that </connor>
<garnt> [ __ ] you know what I mean but I'm </garnt>
<garnt> trying to get to the point where I'm </garnt>
<garnt> comfortable with just like taking </garnt>
<garnt> a little bit of time and just </garnt>
<connor> really doing stuff and just seeing </connor>
<garnt> different cultures and just seeing </garnt>
<garnt> different ways of thinking and just </garnt>
<garnt> seeing different cultures and </garnt>
<garnt> seeing different people I just I just </garnt>
<garnt> I just I just want to see a lot of people </garnt>
<garnt> just really understanding the concept </garnt>
<garnt> of like that yeah but it's like </garnt>
<joey> I'm not really gonna try to just show </joey>
<joey> your entire life story just like just </joey>
<joey> like a little bit you know </ </      < <     
```

```
<joey> who are just like that it's like </joey>
<joey> just like just like just like </joey>
<joey> just the differences in language because I </joey>
<joey> remember as a kid when I was like </joey>
<joey> just thinking about it and I was like </joey>
<joey> I don't like the way that my grandma </joey>
<joey> speaks because she just goes </joey>
<joey> like you know like me </joey>
<joey> and me and me and me you know what I </joey>
<joey> mean like that's how it goes and </joey>
<joey> then we would like go to restaurants </joey>
<joey> and sometimes they would do like </joey>
<joey> American dishes and I'm like oh that's </joey>
<joey> weird I don't like that that's odd </joey>
<joey> that's odd I'm like you know I don't </joey>
<joey> want you know I don't want you know </joey>
<joey> because like it's like you know in </joey>
<joey> my mind I'm like oh I don't understand </joey>
<joey> this and then I see a different </joey>
<joey>      </        <                               
```

```
<joey> in terms of culture and everything. </joey>
<joey> - [Joey] Yeah.
- [Garnt] Yeah, yeah. </joey>
<joey> - And I remember I had to ask Sydney, </joey>
<joey> 'cause I was like, "If
you're asking if you're </joey>
<joey> an american and you're asking
if you're a joey, </joey>
<joey> is it a big deal?" </joey>
<joey> And she's like, "No, no, no, no." </joey>
<joey> And I'm like, "Okay, okay, okay." </joey>
<joey> - I can understand why it's a big deal </joey>
<joey> because I've been
living here for like two months </joey>
<joey> and I think I've seen
this side of America. </joey>
<joey> I can understand why people
would be confused, right? </joey>
<joey> People who are like,
"Oh, oh, I'm an american." </joey>
<joey> - [Connor] Yeah.
- [Joey] Yeah, yeah, yeah. </joey>
<joey> - [Garnt] Yeah. </joey>
<joey> - [Connor] Yeah. </joey>
<joey> - I don't know if there's
any like American show </joey>
<joey> where l   m        m        
```

```
<garnt> i think americans are like i think </garnt>
<garnt> americans are like too honest and i think </garnt>
<garnt> that's why they're like so good at </garnt>
<garnt> trying to convince other countries to </garnt>
<garnt> just put americans in the same box because </garnt>
<garnt> they're like they can like make </garnt>
<garnt> them look like you're just [ __ ] </garnt>
<garnt> talking to a [ __ ] brain dead </garnt>
<garnt> [Laughter] </garnt>
<garnt> you're you're like [ __ ] like i i just </garnt>
<garnt> don't want to see americans in the same </garnt>
<garnt> box of like i think americans are just </garnt>
<garnt> too honest and i think that's why </garnt>
<garnt> they're so good at convincing people </garnt>
<garnt> to put americans in the same box of </garnt>
<garnt> like i never like i think i think </garnt>
<garnt> americans are just like they just like </garnt>
<garnt> it's just like it's just like they're </garnt <    < 
```

```
<garnt> no no no no no no no </garnt>
<garnt> um what do you mean what do you mean </garnt>
<garnt> what do you mean what do you mean </garnt>
<garnt> what do you mean what do you mean </garnt>
<connor> what am I trying to say no no no no no </connor>
<connor> no no we're not trying to be rude because </connor>
<connor> we're not trying to be rude but yeah </connor>
<connor> so there are like different levels </connor>
<joey> and different cultures and different </joey>
<joey> accents so sometimes it's just like </joey>
<joey> it's hard to understand right because </joey>
<joey> for example like in america people </joey>
<joey> have like accents that are very much like </joey>
<joey> you know like i guess they're from </joey>
<joey> like north america or something but it's </joey>
<joey> not like i don't know it's not like </joey>
<joey> accent kind of like yeah it's like </joey>
<joey> it's not like there's a certain accent </joey>
<joey> that  <  <      </ <    <     <  <                
```

## Bloom 560M

```
<joey> oh yeah so basically yeah yeah so </joey>
<joey> basically like the the american way of </joey>
<joey> thinking is that you know you have to go </joey>
<joey> home at a certain time yeah and then you </joey>
<joey> can tell when the Japanese are okay </joey>
<joey> because you know in the in the in in the </joey>
<joey> house in the morning and stuff like that </joey>
<joey> you can tell when they're okay because </joey>
<joey> you know it's it's it's kind of like a </joey>
<joey> little like a test for like for me it's </joey>
<joey> to me it kind of like it kind of like </joey>
<joey> a test to see if there's any like </joey>
<connor> differences between the two cultures </connor>
<joey> yeah it kind of it kind of is like a </joey>
<joey> test to see if there's any differences </joey>
<joey> between the two cultures yeah it's like </joey>
<garnt> oh it's the same with you for example </garnt>
<joey> like for example like you know going </joey>
<joey> to the gym and stuff like that you can </joey>
<joey> tell immediately you know when they're </joey>
<joey> having a good time you know in the </joey>
<joey> morning you can tell when they're having </joey>
<joey> like a good time in the morning </joey>
<joey> because like you know when you go to a </joey>
<connor> gym it's usually like the [ __ ] </connor>
<connor> everyone's like you know everyone's like </connor>
<connor> you know everyone's like busy it's like </connor>
<connor> I'm not doing anything until I go to the </connor>
<connor> gym and then you get to the room and </connor>
<connor> everyone's like oh he's having a good </connor>
<connor> time right now he makes a good [ __ ] </connor>
<connor> out of it </connor>
<connor> because it's like they're having a </connor>
<connor> good time but like you know when you're </connor>
<connor> watching Japanese TV the the whole </connor>
<joey> episodes are just like oh yeah the </joey>
<joey> american way of thinking is that you </joey>
<joey> have to go home at a certain time yeah </joey>
<joey> and then you get to the room and it's </joey>
<joey> like oh I guess that was that was a </joey>
<joey> really cool way of thinking yeah </joey>
<joey> um but yeah I mean like I don't know a </joey>
<joey> lot about Japan personally but like a </joey>
<joey> lot of the way you're just like talking </joey>
<joey> about Japan and like the way that the </joey>
<joey> we live in Japan and everything like </joey>
<joey> that yeah yeah that's all like that's </joey>
<joey> a lot of it I mean it's just it's a </joey>
<joey> very very very slow way of thinking right </joey>
<joey> because it's a very very very slow way </joey>
<joey> of thinking and people in Japan are way </joey>
<joey> more like you know people are way more </joey>
<joey> open to ugh ugh ugh ugh ugh ugh ugh ugh ugh </joey>
<joey> yeah a lot more so yeah and a lot of ugh </joe ugh ugh
```

```
<garnt> it's like the most insane thing to do </garnt>
<garnt> in the world I mean yeah I think I think </garnt>
<garnt> you know I think the reason why a lot of </garnt>
<garnt> the people who are like uh you know </garnt>
<garnt> foreign and uh uh international </garnt>
<garnt> people are like people who are more </garnt>
<garnt> like on the edge of the spectrum yeah </garnt>
<garnt> for some reason </garnt>
<garnt> um it's been like decades since the </garnt>
<garnt> last time ever like a single person is </garnt>
<garnt> like hey hey hey this is the only place </garnt>
<garnt> that you can live in every other country </garnt>
<garnt> you know because it's like you know </garnt>
<joey> it's it's it's it's it's it's it's not just </joey>
<connor> Japan it's not just the Japanese we </connor>
<joey> are Americans as well yeah </joey>
<joey> yeah it's it's it's </joey>
<joey> it's it's like a system that is kind of </joey>
<joey> built for like certain things that </joey>
<garnt> Japan does but it's also like a lot of </garnt>
<garnt> the times some of the rules that are </garnt>
<garnt> broken yeah because it's it's it's it's </garnt>
<garnt> like the rules are broken in a way </garnt>
<garnt> where people are just like oh yeah </garnt>
<garnt> yeah yeah yeah yeah yeah yeah yeah </garnt>
<garnt> and it's like and it's like you know </garnt>
<garnt> like I I think I I think as well the </garnt>
<garnt> same thing with like the uh </garnt>
<garnt> international community as well </garnt>
<garnt> because it's like I think the one thing </garnt>
<garnt> that I always find fascinating is like </garnt>
<garnt> everyone's like oh yeah Japan is cool </garnt>
<garnt> yeah you know I think it's because </garnt>
<garnt> there's no other country that you can </garnt>
<garnt> compare to Japan in that kind of </garnt>
<garnt> sense right it's like you know you know </garnt>
<garnt> everyone always sees Japan being like </garnt>
<joey> oh I think Japan is cool </joey>
<joey> but it is Japan is like one of the </joey>
<garnt> coolest countries in the world I think </garnt>
<garnt> yeah it is it is like in terms of </garnt>
<garnt> popularity yeah yeah yeah it is it is </garnt>
<garnt> it's like one of the most unique </garnt>
<garnt> cultures in the world you know and </garnt>
<garnt> it's it's like I I I think a lot of the </garnt>
<garnt> reasons why people don't feel </garnt>
<garnt> strongly about Japan is because of that </garnt>
<garnt> culture but a lot of the ughs that you </garnt>
<garnt> see as Japanese people here are ughs </garnt>
<garnt> that ughs are just the ughs that </garnt>
<garnt> people will see ughs are ughs that </garnt>
<garnt> people ughs are ughs that ughs ughs </garnt>
<joey> that ughs ughs ughs ugh ugh ugh ugh ugh </joey>
<joey> ugh ugh ugh ugh ugh ugh ugh ugh ugh ugh ugh </joey>
<garnt> ugh ugh ugh ugh ugh ugh ugh ugh ugh ugh ugh ugh ugh
```

```
<garnt> - Yeah, I mean, I'm just
kind of like, I don't know, </garnt>
<garnt> like I'm not really a fan of the word, </garnt>
<connor> not that I'm not really a fan of the word, </connor>
<connor> but I don't know what it's like to be like, </connor>
<garnt> I don't know what it is. </garnt>
<garnt> I just don't like it. </garnt>
<garnt> - It's just the word. </garnt>
<connor> - It's just the word, right? </connor>
<connor> - I don't know what it is to be like. </connor>
<connor> - I mean, I don't know
what it's like for me </connor>
<connor> to be like, you know what? </connor>
<connor> I like this country more than other things. </connor>
<connor> It's something that I like. </connor>
<connor> - I think it's the opposite
for Americans as well. </connor>
<connor> - Right, right? </connor>
<connor> - Right. </connor>
<connor> - I don't know why, </connor>
<connor> I don't know why, </connor>
<joey> I don't know why Americans
are so fucking weird. </joey>
<joey> - I know, I don't know. </joey>
<joey> - I don't know what it is about Americans. </joey>
<joey> I don't know if I've said it on purpose, </joey>
<joey> but I don't know what it is about Americans </joey>
<joey> that's so much more different to normal. </joey>
<joey> - Yeah, yeah, yeah. </joey>
<joey> - I just think that the
general stereotype of Americans </joey>
<joey> is just like, you know,
they're a little too British </joey>
<joey> to talk to the rest of
the world, you know? </joey>
<garnt> - Yeah, I mean, it is weird
that I feel like America </garnt>
<connor> is the only country that I feel </connor>
<connor> like is just like, </connor>
<connor> if I go to another country </connor>
<connor> and I feel like I have
the same mentality, </connor>
<connor> I have the same way of thinking. </connor>
<connor> - Oh yeah, yeah, yeah. </connor>
<connor> - I think that's why like... </connor>
<connor> - I think that Americans
are just so much more </connor>
<connor> British than you think. </connor>
<connor> - I think so. </connor>
<connor> - I think that's why it feels so weird. </connor>
<connor> Like I feel like Americans are just people </connor>
<garnt> that have no interest in what
other people have to ughing ugh. </garnt>
<garnt> - Yeah. </garnt>
<joey> - I hate that word. </joey>
<joey> - What I love about Americans is that people </joeey>
<joey> don't ugh ugh ugh ugh ugh. </joey>
<joey> - ugh ugh ugh ugh ugh ugh ugh ugh ugh ugh ugh ugh ugh
```

```
<joey> you know what the most american
thing about japan is that </joey>
<joey> everyone here is so different to us </joey>
<joey> um and that's because you know </joey>
<joey> the people here are the same as us </joey>
<connor> yeah because the only way that we can </connor>
<connor> communicate with each other is through </connor>
<connor> what we call our differences </connor>
<connor> um so you know we talk with each other </connor>
<connor> through our differences and not even </connor>
<connor> that was our idea of having a conversation </connor>
<joey> that's already sounds like a [ __ ] </joey>
<joey> conversation I don't know why yeah </joey>
<garnt> um you know we don't talk about our </garnt>
<garnt> differences but what I love about japan </garnt>
<connor> is that you can you can really </connor>
<connor> distinguish between certain areas of </connor>
<joey> japan that are very similar to one another </joey>
<connor> but still very different to one another </connor>
<joey> um because you know some of the parts of </joey>
<joey> japan that like you can still see people </joey>
<connor> from across the world yeah yeah yeah </connor>
<joey> yeah but some of the different parts </joey>
<connor> are so different from each other </connor>
<connor> um and you can appreciate that you can </connor>
<connor> appreciate that a lot of the time when </connor>
<connor> the culture is like you know not </connor>
<connor> uniform but like you know you can get </connor>
<connor> across the differences and you can </connor>
<connor> appreciate the differences and the </connor>
<connor> value of them and the interaction that </connor>
<connor> that just there is no in between </connor>
<connor> um and you know the one thing I really </connor>
<connor> enjoyed about japan is that I just I </connor>
<connor> just I just I I like I I get to talk to </connor>
<connor> people who are like different from </connor>
<joey> me because you know they you know </joey>
<joey> you know they live here in the same </joey>
<garnt> household as me </garnt>
<garnt> and you know that the same way with you </garnt>
<garnt> they're not the same people as you </garnt>
<garnt> yeah because you know you get to talk </garnt>
<garnt> to them and they have the same </garnt>
<garnt> characteristics that you have as a </garnt>
<garnt> foreigner like you know there's something </garnt>
<garnt> about having that kind of </garnt>
<connor> interaction where I think it's a lot </connor>
<connor> of the iverse where the iverse is </connor>
<connor> the iverse of iverse where I think </connor>
<connor> it's iverse iverse where I like I get </connor>
<joey> to talk to people who I see iverse iverse </joey>
<garnt> iverse iverse iverse  </garnt>
<garnt>      </garnt>
<garnt>      </garnt>
<joey> um      </joey>
<joey>     </joey>
<garnt>     </garnt>
<joey>   <joey>         </joey>
<connor>     </connor>
<connor>          </connor>
<connor>         </conno>
<garnt>                </garnt>
<garnt>                         <garnt>                              <connor>                                                                                                                                                                                                                                                                                                                                                               </garnt>
<connor> - So basically I was like, </connor>
<connor> I'm going to bring a copy
of "Eyeshield 21" and- </connor>
<connor> - And you can also watch the
episode with the boys as well. </connor>
<connor> - [Joey] Yeah. </connor>
<joey> - And they were like, </joey>
<joey> "Yeah, it was good." </joey>
<joey> And I was doing the voice
over for like a minute, </joey>
<joey> just fucking grunting the
words in my head. </joey>
<joey> I'm like, "Don't fucking
mute me, don't fucking mute." </joey>
<joey> (Garnt laughing) </joey>
<joey> But I was like, "Yeah, no
mute, just keep doing it." </joey>
<joey> And so I do it for two minutes. </joey>
<joey> And then I'm just like... </joey>
<connor> (Joey and Garnt laughing) </connor>
<connor> (Garnt and Joey laughing) </connor>
<connor> - I was like, "Why is
this funny to you?" </connor>
<connor> - Yeah. </connor>
<joey> - And I was like, "Oh, it's
the most like Disney-esque, </joey>
<joey> like cartoonish fucking story ever." </joey>
<joey> And I was like, "Okay, this
is the best fucking thing. </joey>
<joey> "That's what I'm laughing at." </joey>
<joey> - The thing is I think the
equivalent of laughing at that </joey>
<joey> was I fucking cry when I
heard about the Oscars. </joey>
<joey> And I'm just like, "This is sad." </joey>
<joey> - I think that was the first
time that I went to see the- </joey>
<joey> - [Joey] The Oscars? </joey>
<joey> - I went to see
```

```
<joey> we got to talk about this for an hour </joey>
<joey> because we were going to go back to </joey>
<joey> australia and australia uh has a lot </joey>
<joey> more history than japan oh yeah yeah </joey>
<joey> and we went to go to go watch the </joey>
<joey> australia kangaroo shows </joey>
<joey> um and then we went to go watch the kangaroo </joey>
<connor> show in australia and then we went to </connor>
<connor> do the kangaroo show and then we went </connor>
<connor> back to the us and then we went back to </connor>
<connor> australia and then we went to go watch </connor>
<connor> kangaroo shows and then we went back to </connor>
<connor> australia and then we went back to the </connor>
<connor> us and then we went back to australia </connor>
<connor> and then we went back to australia </connor>
<connor> and then we went back to the uk and then </connor>
<connor> we went back to the uk and then we went </connor>
<connor> back to australia and then we went back </connor>
<connor> to the uk and then we went back to the </connor>
<connor> us and then we went back to the us </connor>
<joey> and then we went back to australia and </joey>
<joey> then we went back to the uk and then we </joey>
<garnt> went back to the us and then we went </garnt>
<garnt> back to australia and then we went back </garnt>
<garnt> to the uk and then we went back to the </garnt>
<garnt> us and then we went back to the uk but </garnt>
<garnt> now we're going to go back to the uk </garnt>
<garnt> and then there's going to be a few </garnt>
<garnt> shows that we still can't watch because </garnt>
<garnt> there's going to be a few shows that we </garnt>
<garnt> can watch but there's going to be a few </garnt>
<garnt> shows that will still be on our </garnt>
<garnt> shelves and there's a there's a there's a </garnt>
<garnt> few shows that are still on our shelves </garnt>
<garnt> which is very very nice that you know </garnt>
<garnt> we've had a few shows that we haven't </garnt>
<garnt> had a chance to watch but still very </garnt>
<garnt> nice and I've been to a few shows </garnt>
<garnt> where it's like it's like the majority </garnt>
<garnt> of the time that we know we can watch </garnt>
<garnt> because we're in a hotel room yeah yeah </garnt>
<garnt> yeah and there's just a few shows that we </garnt>
<garnt> haven't seen before and we're like </garnt>
<garnt> [ __ ] we have to wait for the next </garnt>
<garnt> show that's coming out yeah so there's </garnt>
<joey> like a few shows that we haven't seen </joey>
<joey> before but nknknknknknknknknknknknk </joey>
<joey> it's like </joey>
<joey> oh my God yeah </joey>
<joey> oh my God </joey>
<joey> oh my God yeah because we have to wait </joey>
<joey> for like the next nknknknknknknk </joey>
<joey> show yeah and uh it's going to be nknknknknk </joey>
<joey> right oh nknknknknknknknknknknknknk </joey>
<joey> and then uh </joey>
<joey> um nknknknknknknknknknknknknknknknk </joey>
<garnt> yeah yeah so nknknknknknknknknknknknk </garnt>
<joey> i just want to shout out the patrons </joey>
<connor> um </connor>
<connor> so nknknknknknknknknknknknknknknk </connor>
<connor> and i'll nknknknknknknknknknknknknknk </connor>
<joe nknknknknknknknknknknknknknk  </joe>
<connor> nknknknknknknknknknknknknknknknknknk </connor>
<connor> nknknknknknknknknknknknknk nknknknknknknk  </co nknknknknknknknknk  </joe nknknknknknknknk  <joe nknknknknknknknk  </joe nknknknknknk  </joe nknknk nknknknknknk  </joe nknknknknk nknknknknk  </joe nknknk nknknk nknknk nknknknk nknknk nknknknk nknknk nknknknk nknknk nknknk nknknknk nknknk nknknknk nknknk nknk nknknk nknknk nknknknk nknknknk nknk nknknk nknknk nknk nknknknk nknknk nknknknk nknknk nknknk nknknk nknknk nknknk nknknknk nknknk nknknk nknknk nknk nknknk nknknk nknknk nknknk nknknk nknknk  nknknk nknk nknknk  </joe nknk   nknknk   nknk   nknknk   nknk   nknk   nknk   nknk                                                                                                                                       be </connor>
<connor>  up in the office yeah. </connor>
<connor> I don't know. </connor>
<connor> I don't know why I like it, </connor>
<connor> but I mean, you get a little bit of it. </connor>
<connor> This is actually a
very nice-looking place. </connor>
<garnt> - Yeah, this is a very nice place. </garnt>
<garnt> - I like how you guys
said the food is good. </garnt>
<garnt> - The food is- </garnt>
<garnt> - You got food. </garnt>
<garnt> - The food is good. </garnt>
<garnt> - I feel like my stomach is just in a </garnt>
<garnt> state of equilibrium right now </garnt>
<garnt> 'cause I'm just sitting
there and I'm like, </garnt>
<garnt> "Okay, this is what I'm feeling now." </garnt>
<garnt> I'm just like, "Okay, the food's okay, </garnt>
<garnt> I'm eating all right, now
```

### LLaMA 7B

```
<connor> is that american people are like </connor>
<connor> you're gonna fuck it up, you're gonna fuck it up </connor>
<connor> and then japanese people are like </connor>
<connor> "oh, you're gonna fuck it up" but we're just </connor>
<garnt> like "yeah, yeah, yeah." </garnt>
<garnt> - Yeah, yeah, yeah. </garnt>
<garnt> - And that's like the one thing </garnt>
<garnt> I appreciate about japanese people is like </garnt>
<garnt> they're like "you're gonna fuck it up, </garnt>
<connor> so you might as well fuck it up." </connor>
<connor> - Yeah, exactly. </connor>
<connor> - You know what I mean? </connor>
<connor> - And then you can just move on from there. </connor>
<connor> It's like I can't say I've never seen </connor>
<connor> a japanese person ever like
regret something they did </connor>
<connor> because they were like "oh,
I fucked this up, oh my god, </connor>
<connor> oh my god" and then you're like </connor>
<connor> "oh well, you fucked it up,
just go fuck it up again." </connor>
<connor> - Yeah, yeah.
- Yeah. </connor>
<connor> - They're like "well, what can be done?" </connor>
<connor> - Yeah. </connor>
<connor> - What can be done? </connor>
<connor> - I've never seen a japanese person </connor>
<connor> ever like regret anything </connor>
<connor> 'cause I feel like
it's just like, "oh well, </connor>
<connor> it's done and it's been done." </connor>
<joey> - Yeah, yeah, yeah. </joey>
<connor> - It's just like "oh well, it's done." </connor>
<connor> - Yeah, exactly.
- It's like. </connor>
<connor> - I love that, I love that. </connor>
<garnt> - Yeah, exactly. </garnt>
<connor> - That's what I like about Japan. </connor>
<connor> - Yeah. </connor>
<connor> - Is that like it's like
there's a whole culture </connor>
<joey> of just "let's get shit over with." </joey>
<connor> - Yeah, exactly. </connor>
<connor> - And just get it over with. </connor>
<connor> - Yeah, exactly. </connor>
<garnt> - I just love that. </garnt>
<connor> - I love that. </connor>
<garnt> - Yeah. </garnt>
<joey> - I love that, I love it. </joey>
<joey> - What do you guys think of the </joey in, </ </ connor paris in </ </ paris in </ </
connor in. </connor in. </connor in. </connor in. </connor in </connor in. </ </connor in. </connor in. </connor in. </connor in. </connor in.
jo </jo </jo </jo </jo </jo> </jo </joey connor </joey> jo jo jo </joey </joey>
<connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in </connor in. </connor in. </connor in. </connor in.
<connor in> Jo Jo </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in.
<connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in. </connor in.
joey </joey. </joey> joey </joey> joey </joey>
<joey> joey </joey>
<joey> connor </joey>
<joey> joey </joey>
<joey> ( > joey </joey>
<joey> ( joey </joey>
<joey> joey </joey>
<joey> joey </joey>
<joey> joey </joey>
<joey> joey </joey>
<joey> joey </joey>
<joey> joey </joey>
<joey> (laughing </joey>
<joey> </joey>
<joey> ( </joey>
<joey> joey </joey>
joey </joey>
<joey> </joey>
<joey> joey </joey>
<joey> </joey>
<joey> </joey>
joey </joey>
<joey> </joey>
<joey> (laughing </joey>
<connor> (laughing </connor>
<connor> in. </connor>
<connor> in. </connor>
<connor> </connor>
<connor> </connor>
<connor> </connor>
<connor> </connor>
```

```
<garnt> and i was like i know it's i know we are </garnt>
<garnt> the same people i know we speak the same language </garnt>
<garnt> but we have these different </garnt>
<garnt> cultural beliefs and stuff like this yeah </garnt>
<joey> um so i thought it would be interesting to </joey>
<joey> compare the two cultures and i know that </joey>
<joey> there's a lot of people who are like well </joey>
<joey> you know japanese and american culture is </joey>
<joey> very similar like i mean i know like it's </joey>
<garnt> a lot of people who are like oh yeah like </garnt>
<garnt> we're the same people yeah we're the same </garnt>
<garnt> people yeah we're the same people yeah we </garnt>
<garnt> are the same people yeah yeah but we have </garnt>
<garnt> different cultural beliefs yeah yeah yeah </garnt>
<connor> yeah yeah yeah yeah yeah but my thing is </connor>
<connor> like even if you look at like the most </connor>
<connor> stereotypical things like i mean i mean like </connor>
<connor> i mean like for example like i mean like </connor>
<connor> for example like i mean like i mean like </connor>
<connor> like i i mean like like i mean like like </connor>
<connor> like for example like i mean like in </connor>
<connor> america for example like if you get a job </connor>
<connor> there's a lot of people who say oh it's so </connor>
<connor> hard to get a job in america i don't know </connor>
<connor> how hard can it be it's not hard it's hard </connor>
<garnt> to get a job in japan yeah it's hard to get </garnt>
<garnt> a job in any country it's hard to get a job </garnt>
<garnt> but you know people in america they're </garnt>
<garnt> like oh it's so hard to get a job in america </garnt>
<garnt> i don't know how hard can it be it's hard to </garnt>
<garnt> get a job in any country it's hard to get a </garnt>
<garnt> job </garnt>
<garnt> but you know people in america they're </garnt>
<garnt> like oh it's so hard to get a job in </garnt>
<garnt> america i don't know how hard can it be it's </garnt>
<garnt> hard to get a job in any country it's hard </garnt>
<connor> to get a job in any country it's hard to </connor>
<connor> get a job in any country it's hard to get a </ i </ </ Gar
```
